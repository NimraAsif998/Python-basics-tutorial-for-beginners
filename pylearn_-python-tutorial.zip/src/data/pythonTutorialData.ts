export interface TutorialStep {
  id: string;
  title: string;
  content: string;
  codeExample?: string;
  explanation?: string;
}

export interface TutorialSection {
  id: string;
  title: string;
  steps: TutorialStep[];
}

export const pythonTutorialData: TutorialSection[] = [
  {
    id: "intro",
    title: "Python Intro",
    steps: [
      {
        id: "what-is-python",
        title: "What is Python?",
        content: "Python is a popular programming language. It was created by Guido van Rossum, and released in 1991.",
        explanation: "It is used for:\n- Web development (server-side)\n- Software development\n- Mathematics\n- System scripting",
        codeExample: "print(\"Hello, World!\")"
      },
      {
        id: "why-python",
        title: "Why Python?",
        content: "Python works on different platforms (Windows, Mac, Linux, Raspberry Pi, etc). Python has a simple syntax similar to the English language.",
        explanation: "Python has syntax that allows developers to write programs with fewer lines than some other programming languages."
      }
    ]
  },
  {
    id: "get-started",
    title: "Python Get Started",
    steps: [
      {
        id: "install",
        title: "Python Install",
        content: "Many PCs and Macs will have python already installed. To check if you have python installed on a Windows PC, search in the start bar for Python or run the following on the Command Line (cmd.exe):\n\nIf you do not have Python installed, you can download it for free from the official website:\n\n<a href=\"https://www.python.org/downloads/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-xl font-bold transition-all no-underline mt-4 shadow-lg shadow-emerald-900/10\">Download Python</a>",
        codeExample: "C:\\Users\\Your Name>python --version"
      }
    ]
  },
  {
    id: "syntax",
    title: "Python Syntax",
    steps: [
      {
        id: "syntax-intro",
        title: "Python Indentation",
        content: "Indentation refers to the spaces at the beginning of a code line. Where in other programming languages the indentation in code is for readability only, the indentation in Python is very important.",
        codeExample: "if 5 > 2:\n  print(\"Five is greater than two!\")",
        explanation: "Python uses indentation to indicate a block of code."
      }
    ]
  },
  {
    id: "variables",
    title: "Python Variables",
    steps: [
      {
        id: "variables-intro",
        title: "Creating Variables",
        content: "Variables are containers for storing data values. Python has no command for declaring a variable. A variable is created the moment you first assign a value to it.",
        codeExample: "x = 5\ny = \"John\"\nprint(x)\nprint(y)"
      }
    ]
  },
  {
    id: "data-types",
    title: "Python Data Types",
    steps: [
      {
        id: "data-types-list",
        title: "Built-in Data Types",
        content: "In programming, data type is an important concept. Variables can store data of different types, and different types can do different things.",
        explanation: "Python has the following data types built-in by default, in these categories:\n- Text Type: str\n- Numeric Types: int, float, complex\n- Sequence Types: list, tuple, range\n- Mapping Type: dict\n- Set Types: set, frozenset\n- Boolean Type: bool\n- Binary Types: bytes, bytearray, memoryview"
      }
    ]
  },
  {
    id: "numbers",
    title: "Python Numbers",
    steps: [
      {
        id: "numbers-intro",
        title: "Python Numbers",
        content: "There are three numeric types in Python:\n- int\n- float\n- complex",
        codeExample: "x = 1    # int\ny = 2.8  # float\nz = 1j   # complex"
      }
    ]
  },
  {
    id: "strings",
    title: "Python Strings",
    steps: [
      {
        id: "strings-intro",
        title: "Python Strings",
        content: "Strings in python are surrounded by either single quotation marks, or double quotation marks.",
        codeExample: "print(\"Hello\")\nprint('Hello')"
      }
    ]
  },
  {
    id: "lists",
    title: "Python Lists",
    steps: [
      {
        id: "lists-intro",
        title: "Python Lists",
        content: "Lists are used to store multiple items in a single variable. Lists are created using square brackets.",
        codeExample: "thislist = [\"apple\", \"banana\", \"cherry\"]\nprint(thislist)",
        explanation: "List items are ordered, changeable, and allow duplicate values."
      },
      {
        id: "list-methods",
        title: "List Methods",
        content: "Python has a set of built-in methods that you can use on lists.",
        codeExample: "fruits = ['apple', 'banana', 'cherry']\nfruits.append(\"orange\")\nfruits.remove(\"banana\")\nprint(fruits)",
        explanation: "Common methods:\n- append(): Adds an element at the end\n- remove(): Removes the item with the specified value\n- pop(): Removes the element at the specified position\n- sort(): Sorts the list"
      }
    ]
  },
  {
    id: "tuples",
    title: "Python Tuples",
    steps: [
      {
        id: "tuples-intro",
        title: "Python Tuples",
        content: "Tuples are used to store multiple items in a single variable. A tuple is a collection which is ordered and unchangeable.",
        codeExample: "thistuple = (\"apple\", \"banana\", \"cherry\")\nprint(thistuple)",
        explanation: "Tuples are written with round brackets."
      }
    ]
  },
  {
    id: "sets",
    title: "Python Sets",
    steps: [
      {
        id: "sets-intro",
        title: "Python Sets",
        content: "Sets are used to store multiple items in a single variable. A set is a collection which is unordered, unchangeable*, and unindexed.",
        codeExample: "thisset = {\"apple\", \"banana\", \"cherry\"}\nprint(thisset)",
        explanation: "Set items are unordered, unchangeable, and do not allow duplicate values."
      },
      {
        id: "set-methods",
        title: "Set Methods",
        content: "Python has a set of built-in methods that you can use on sets.",
        codeExample: "thisset = {\"apple\", \"banana\", \"cherry\"}\nthisset.add(\"orange\")\nthisset.discard(\"banana\")\nprint(thisset)"
      }
    ]
  },
  {
    id: "dictionaries",
    title: "Python Dictionaries",
    steps: [
      {
        id: "dicts-intro",
        title: "Python Dictionaries",
        content: "Dictionaries are used to store data values in key:value pairs. A dictionary is a collection which is ordered*, changeable and do not allow duplicates.",
        codeExample: "thisdict = {\n  \"brand\": \"Ford\",\n  \"model\": \"Mustang\",\n  \"year\": 1964\n}\nprint(thisdict)",
        explanation: "Dictionaries are written with curly brackets, and have keys and values."
      },
      {
        id: "dict-methods",
        title: "Dictionary Methods",
        content: "Python has a set of built-in methods that you can use on dictionaries.",
        codeExample: "car = {\"brand\": \"Ford\", \"model\": \"Mustang\"}\ncar.update({\"year\": 2020})\nmodel = car.get(\"model\")\nprint(car)",
        explanation: "Common methods:\n- get(): Returns the value of the specified key\n- keys(): Returns a list containing the dictionary's keys\n- values(): Returns a list of all the values in the dictionary\n- update(): Updates the dictionary with the specified key-value pairs"
      }
    ]
  },
  {
    id: "conditionals",
    title: "Python If...Else",
    steps: [
      {
        id: "if-else",
        title: "Python Conditions",
        content: "Python supports the usual logical conditions from mathematics. These conditions can be used in several ways, most commonly in 'if statements' and loops.",
        codeExample: "a = 33\nb = 200\nif b > a:\n  print(\"b is greater than a\")\nelif a == b:\n  print(\"a and b are equal\")\nelse:\n  print(\"a is greater than b\")"
      }
    ]
  },
  {
    id: "loops",
    title: "Python Loops",
    steps: [
      {
        id: "while-loop",
        title: "While Loop",
        content: "With the while loop we can execute a set of statements as long as a condition is true.",
        codeExample: "i = 1\nwhile i < 6:\n  print(i)\n  i += 1"
      },
      {
        id: "for-loop",
        title: "For Loop",
        content: "A for loop is used for iterating over a sequence (that is either a list, a tuple, a dictionary, a set, or a string).",
        codeExample: "fruits = [\"apple\", \"banana\", \"cherry\"]\nfor x in fruits:\n  print(x)"
      }
    ]
  },
  {
    id: "functions",
    title: "Python Functions",
    steps: [
      {
        id: "functions-intro",
        title: "Creating a Function",
        content: "A function is a block of code which only runs when it is called. You can pass data, known as parameters, into a function.",
        codeExample: "def my_function():\n  print(\"Hello from a function\")\n\nmy_function()",
        explanation: "In Python a function is defined using the def keyword."
      },
      {
        id: "arguments",
        title: "Arguments",
        content: "Information can be passed into functions as arguments. Arguments are specified after the function name, inside the parentheses.",
        codeExample: "def my_function(fname):\n  print(fname + \" Refsnes\")\n\nmy_function(\"Emil\")\nmy_function(\"Tobias\")"
      }
    ]
  },
  {
    id: "modules",
    title: "Python Modules",
    steps: [
      {
        id: "modules-intro",
        title: "What is a Module?",
        content: "Consider a module to be the same as a code library. A file containing a set of functions you want to include in your application.",
        codeExample: "import math\nprint(math.sqrt(64))",
        explanation: "To create a module just save the code you want in a file with the file extension .py. To use a module, use the import statement."
      }
    ]
  },
  {
    id: "random",
    title: "Python Random",
    steps: [
      {
        id: "random-intro",
        title: "Random Module",
        content: "Python has a built-in module that you can use to make random numbers.",
        codeExample: "import random\n\nprint(random.randrange(1, 10))",
        explanation: "The random module has a set of methods to create random numbers."
      }
    ]
  },
  {
    id: "datetime",
    title: "Python Datetime",
    steps: [
      {
        id: "datetime-intro",
        title: "Python Dates",
        content: "A date in Python is not a data type of its own, but we can import a module named datetime to work with dates as date objects.",
        codeExample: "import datetime\n\nx = datetime.datetime.now()\nprint(x)",
        explanation: "The datetime module has many methods to return information about the date object."
      },
      {
        id: "date-output",
        title: "Date Output",
        content: "When we execute the code from the example above, the result will be: 2024-05-17 14:45:08.003515 (or whatever the current date/time is).",
        codeExample: "import datetime\n\nx = datetime.datetime.now()\n\nprint(x.year)\nprint(x.strftime(\"%A\"))",
        explanation: "The date contains year, month, day, hour, minute, second, and microsecond."
      }
    ]
  }
];
