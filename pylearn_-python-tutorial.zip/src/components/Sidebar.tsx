import React from 'react';
import { pythonTutorialData } from '../data/pythonTutorialData';

interface SidebarProps {
  activeStepId: string;
  onStepSelect: (id: string) => void;
  isOpen: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeStepId, onStepSelect, isOpen }) => {
  return (
    <aside 
      id="sidebar" 
      className={`fixed top-16 bottom-0 left-0 w-64 bg-zinc-50 border-r border-zinc-200 overflow-y-auto z-40 transition-transform duration-300 md:translate-x-0 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
    >
      <div className="p-4">
        <h2 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-4">Python Tutorial</h2>
        <nav className="space-y-1">
          {pythonTutorialData.map((section) => (
            <div key={section.id} className="mb-4">
              <h3 className="px-3 py-2 text-sm font-semibold text-zinc-900">{section.title}</h3>
              <div className="space-y-1">
                {section.steps.map((step) => (
                  <button
                    key={step.id}
                    onClick={() => onStepSelect(step.id)}
                    className={`w-full text-left px-3 py-1.5 text-sm rounded-md transition-colors ${
                      activeStepId === step.id 
                        ? 'bg-emerald-600 text-white font-medium' 
                        : 'text-zinc-600 hover:bg-zinc-200'
                    }`}
                  >
                    {step.title}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </nav>
      </div>
    </aside>
  );
};
