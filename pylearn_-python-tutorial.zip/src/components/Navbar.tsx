import React from 'react';
import { Menu, X } from 'lucide-react';

interface NavbarProps {
  onMenuToggle: () => void;
  isSidebarOpen: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({ onMenuToggle, isSidebarOpen }) => {
  return (
    <nav id="navbar" className="fixed top-0 left-0 right-0 h-16 bg-white border-b border-zinc-200 z-50 flex items-center px-4 md:px-6">
      <button 
        onClick={onMenuToggle}
        className="p-2 mr-2 hover:bg-zinc-100 rounded-lg md:hidden"
        aria-label="Toggle Menu"
      >
        {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
      </button>
      
      <div className="flex items-center gap-2 mr-8">
        <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white">
          <span className="font-bold text-lg">Py</span>
        </div>
        <span className="font-bold text-xl tracking-tight hidden sm:block">PyLearn</span>
      </div>

      <div className="ml-auto flex items-center gap-4">
        <span className="text-xs font-medium text-zinc-400 uppercase tracking-wider hidden md:block">Python Reference</span>
      </div>
    </nav>
  );
};
