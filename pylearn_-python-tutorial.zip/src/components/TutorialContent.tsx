import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TutorialStep } from '../data/pythonTutorialData';
import { CodeExample } from './CodeExample';
import { ChevronRight, ChevronLeft } from 'lucide-react';
import Markdown from 'react-markdown';
import rehypeRaw from 'rehype-raw';

interface TutorialContentProps {
  step: TutorialStep;
  onNext: () => void;
  onPrev: () => void;
  hasPrev: boolean;
  hasNext: boolean;
  onTryCode: (code: string) => void;
}

export const TutorialContent: React.FC<TutorialContentProps> = ({ step, onNext, onPrev, hasPrev, hasNext, onTryCode }) => {
  return (
    <div id="tutorial-content" className="max-w-4xl mx-auto py-8 px-4 md:px-8">
      <AnimatePresence mode="wait">
        <motion.div
          key={step.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          <h1 className="text-4xl font-bold text-zinc-900 mb-6 tracking-tight">{step.title}</h1>
          
          <div className="prose prose-zinc max-w-none">
            <div className="text-lg text-zinc-600 leading-relaxed mb-6 markdown-content">
              <Markdown rehypePlugins={[rehypeRaw]}>{step.content}</Markdown>
            </div>

            {step.explanation && (
              <div className="bg-emerald-50 border-l-4 border-emerald-500 p-4 my-6 rounded-r-lg">
                <div className="text-emerald-900 whitespace-pre-line markdown-content">
                  <Markdown rehypePlugins={[rehypeRaw]}>{step.explanation}</Markdown>
                </div>
              </div>
            )}

            {step.codeExample && (
              <CodeExample code={step.codeExample} onTry={onTryCode} />
            )}
          </div>

          <div className="flex items-center justify-between mt-12 pt-8 border-t border-zinc-200">
            <button
              onClick={onPrev}
              disabled={!hasPrev}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
                hasPrev 
                  ? 'bg-zinc-100 text-zinc-900 hover:bg-zinc-200' 
                  : 'text-zinc-300 cursor-not-allowed'
              }`}
            >
              <ChevronLeft size={20} />
              Previous
            </button>
            
            <button
              onClick={onNext}
              disabled={!hasNext}
              className={`flex items-center gap-2 px-6 py-2 rounded-lg font-medium transition-all ${
                hasNext 
                  ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-md hover:shadow-lg' 
                  : 'bg-zinc-100 text-zinc-300 cursor-not-allowed'
              }`}
            >
              Next
              <ChevronRight size={20} />
            </button>
          </div>
        </motion.div>
      </AnimatePresence>

      <footer className="mt-20 pt-8 border-t border-zinc-200 text-center text-zinc-400 text-sm">
        <p>© 2024 PyLearn Tutorial. All rights reserved.</p>
        <div className="flex justify-center gap-4 mt-4">
          <a href="#" className="hover:text-emerald-600">Privacy Policy</a>
          <a href="#" className="hover:text-emerald-600">Terms of Service</a>
          <a href="#" className="hover:text-emerald-600">Contact Us</a>
        </div>
      </footer>
    </div>
  );
};
