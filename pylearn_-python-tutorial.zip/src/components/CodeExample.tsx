import React from 'react';
import { Play } from 'lucide-react';

interface CodeExampleProps {
  code: string;
  onTry?: (code: string) => void;
}

export const CodeExample: React.FC<CodeExampleProps> = ({ code, onTry }) => {
  return (
    <div id="code-example" className="my-6 bg-zinc-900 rounded-xl overflow-hidden shadow-lg border border-zinc-800">
      <div className="px-4 py-2 bg-zinc-800 flex items-center justify-between border-b border-zinc-700">
        <span className="text-xs font-mono text-zinc-400">Example</span>
        <button 
          className="flex items-center gap-1.5 text-xs font-medium text-emerald-400 hover:text-emerald-300 transition-colors"
          onClick={() => onTry?.(code)}
        >
          <Play size={14} />
          Try it Yourself »
        </button>
      </div>
      <pre className="p-6 overflow-x-auto">
        <code className="font-mono text-sm text-zinc-100 leading-relaxed">
          {code}
        </code>
      </pre>
    </div>
  );
};
