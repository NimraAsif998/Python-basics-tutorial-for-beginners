import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Play, Loader2, Terminal, Copy, Check } from 'lucide-react';
import Editor from 'react-simple-code-editor';
// @ts-ignore
import { highlight, languages } from 'prismjs/components/prism-core';
import 'prismjs/components/prism-python';
import 'prismjs/themes/prism-tomorrow.css';

interface PlaygroundModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialCode: string;
}

declare global {
  interface Window {
    loadPyodide: any;
  }
}

export const PlaygroundModal: React.FC<PlaygroundModalProps> = ({ isOpen, onClose, initialCode }) => {
  const [code, setCode] = useState(initialCode);
  const [output, setOutput] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isPyodideReady, setIsPyodideReady] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const pyodideRef = useRef<any>(null);

  useEffect(() => {
    if (isOpen) {
      setCode(initialCode);
      setOutput([]);
      loadPyodideInstance();
    }
  }, [isOpen, initialCode]);

  const loadPyodideInstance = async () => {
    if (pyodideRef.current) return;
    
    setIsLoading(true);
    try {
      // Load script dynamically
      if (!window.loadPyodide) {
        const script = document.createElement('script');
        script.src = "https://cdn.jsdelivr.net/pyodide/v0.25.0/full/pyodide.js";
        script.async = true;
        document.head.appendChild(script);
        await new Promise((resolve) => (script.onload = resolve));
      }

      pyodideRef.current = await window.loadPyodide({
        indexURL: "https://cdn.jsdelivr.net/pyodide/v0.25.0/full/",
      });
      setIsPyodideReady(true);
    } catch (err) {
      console.error("Failed to load Pyodide", err);
      setOutput(["Error: Failed to load Python environment. Please check your internet connection."]);
    } finally {
      setIsLoading(false);
    }
  };

  const runCode = async () => {
    if (!pyodideRef.current) return;
    
    setIsLoading(true);
    setOutput([]);
    
    try {
      // Redirect stdout to capture print statements
      pyodideRef.current.runPython(`
        import sys
        import io
        sys.stdout = io.StringIO()
      `);

      await pyodideRef.current.runPythonAsync(code);
      
      const stdout = pyodideRef.current.runPython("sys.stdout.getvalue()");
      setOutput(stdout.split('\n').filter((line: string) => line !== ''));
    } catch (err: any) {
      setOutput([`Error: ${err.message}`]);
    } finally {
      setIsLoading(false);
    }
  };

  const copyCode = () => {
    navigator.clipboard.writeText(code);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4 md:p-8"
      >
        <motion.div 
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          className="bg-zinc-900 w-full max-w-5xl h-[85vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-zinc-800"
        >
          {/* Header */}
          <div className="px-6 py-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/50">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white">
                <Play size={18} fill="currentColor" />
              </div>
              <div>
                <h2 className="text-white font-bold">Python Playground</h2>
                <p className="text-zinc-500 text-xs">Interactive Python 3.11 Environment</p>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-zinc-800 rounded-full text-zinc-400 transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          {/* Main Content */}
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            {/* Editor Area */}
            <div className="flex-1 flex flex-col border-r border-zinc-800">
              <div className="px-4 py-2 bg-zinc-800/50 flex items-center justify-between">
                <span className="text-xs font-mono text-zinc-400">main.py</span>
                <button 
                  onClick={copyCode}
                  className="text-zinc-400 hover:text-white transition-colors p-1"
                  title="Copy Code"
                >
                  {isCopied ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
                </button>
              </div>
              <div className="flex-1 overflow-auto bg-zinc-950 p-4">
                <Editor
                  value={code}
                  onValueChange={code => setCode(code)}
                  highlight={code => highlight(code, languages.python, 'python')}
                  padding={10}
                  style={{
                    fontFamily: '"JetBrains Mono", monospace',
                    fontSize: 14,
                    minHeight: '100%',
                    backgroundColor: 'transparent',
                  }}
                  className="outline-none text-zinc-100"
                />
              </div>
              <div className="p-4 bg-zinc-900 border-t border-zinc-800 flex justify-end">
                <button 
                  onClick={runCode}
                  disabled={isLoading || !isPyodideReady}
                  className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-zinc-700 text-white px-6 py-2.5 rounded-xl font-bold transition-all shadow-lg shadow-emerald-900/20"
                >
                  {isLoading ? <Loader2 size={18} className="animate-spin" /> : <Play size={18} fill="currentColor" />}
                  Run Script
                </button>
              </div>
            </div>

            {/* Output Area */}
            <div className="w-full md:w-80 bg-zinc-950 flex flex-col">
              <div className="px-4 py-2 bg-zinc-800/50 flex items-center gap-2">
                <Terminal size={14} className="text-zinc-400" />
                <span className="text-xs font-mono text-zinc-400">Console Output</span>
              </div>
              <div className="flex-1 p-4 font-mono text-sm overflow-auto">
                {!isPyodideReady && !isLoading && (
                  <p className="text-zinc-600 italic">Initializing environment...</p>
                )}
                {isLoading && output.length === 0 && (
                  <div className="flex items-center gap-2 text-emerald-500">
                    <Loader2 size={14} className="animate-spin" />
                    <span>Executing...</span>
                  </div>
                )}
                {output.map((line, i) => (
                  <div key={i} className={`mb-1 ${line.startsWith('Error:') ? 'text-red-400' : 'text-zinc-300'}`}>
                    <span className="text-zinc-600 mr-2">›</span>
                    {line}
                  </div>
                ))}
                {isPyodideReady && output.length === 0 && !isLoading && (
                  <p className="text-zinc-700 italic">Click "Run Script" to see output</p>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
