import React, { useState, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { TutorialContent } from './components/TutorialContent';
import { pythonTutorialData } from './data/pythonTutorialData';
import { PlaygroundModal } from './components/PlaygroundModal';

export default function App() {
  const [activeStepId, setActiveStepId] = useState(pythonTutorialData[0].steps[0].id);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [playgroundState, setPlaygroundState] = useState<{ isOpen: boolean; code: string }>({
    isOpen: false,
    code: '',
  });

  // Flatten all steps for easier navigation
  const allSteps = useMemo(() => {
    return pythonTutorialData.flatMap(section => section.steps);
  }, []);

  const currentStepIndex = useMemo(() => {
    return allSteps.findIndex(step => step.id === activeStepId);
  }, [activeStepId, allSteps]);

  const currentStep = allSteps[currentStepIndex];

  const handleNext = () => {
    if (currentStepIndex < allSteps.length - 1) {
      setActiveStepId(allSteps[currentStepIndex + 1].id);
      window.scrollTo(0, 0);
    }
  };

  const handlePrev = () => {
    if (currentStepIndex > 0) {
      setActiveStepId(allSteps[currentStepIndex - 1].id);
      window.scrollTo(0, 0);
    }
  };

  const handleStepSelect = (id: string) => {
    setActiveStepId(id);
    setIsSidebarOpen(false);
    window.scrollTo(0, 0);
  };

  const openPlayground = (code: string) => {
    setPlaygroundState({ isOpen: true, code });
  };

  return (
    <div id="app-root" className="min-h-screen bg-white font-sans text-zinc-900">
      <Navbar 
        onMenuToggle={() => setIsSidebarOpen(!isSidebarOpen)} 
        isSidebarOpen={isSidebarOpen} 
      />
      
      <div className="flex">
        <Sidebar 
          activeStepId={activeStepId} 
          onStepSelect={handleStepSelect} 
          isOpen={isSidebarOpen}
        />
        
        <main className="flex-1 md:ml-64 pt-16 min-h-screen">
          <TutorialContent 
            step={currentStep}
            onNext={handleNext}
            onPrev={handlePrev}
            hasPrev={currentStepIndex > 0}
            hasNext={currentStepIndex < allSteps.length - 1}
            onTryCode={openPlayground}
          />
        </main>
      </div>

      <PlaygroundModal 
        isOpen={playgroundState.isOpen}
        initialCode={playgroundState.code}
        onClose={() => setPlaygroundState(prev => ({ ...prev, isOpen: false }))}
      />

      {/* Mobile Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-30 md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
    </div>
  );
}
